class task01{
	public static void main(String [] args){
	System.out.println("////////\\\\\\\\\\\\\\\\\\");
	System.out.println("  Studen Point            ");
	System.out.println("\\\\\\\\\\\\\\\\\\////////");
	System.out.println("Lab  Bouns   Total");
	System.out.println("---  -----   ------");
	System.out.println("43     7        50 ");
	System.out.println("50     8        58 ");
	System.out.println("39     10       49 ");
}
}