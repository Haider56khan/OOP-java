class task06{
	public static void main(String args[]){
	int vDollor=3;
	double vRupees=347.67;
	System.out.print((vDollor)*(vRupees));
}
} 