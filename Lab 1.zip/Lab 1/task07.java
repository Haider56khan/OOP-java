import java.util.Scanner;

public class task07{
	public static void main(String args[]){
	Scanner myvalue1 = new Scanner(System.in);
	Scanner myvalue2 = new Scanner(System.in);
	double radius;
	double height;

	System.out.println("Enter Radius");
	radius= myvalue1.nextDouble();
	System.out.println("Enter Hight");
	height = myvalue2.nextDouble();

	System.out.println("Value :"+(3.14*(radius*radius)*height));
}
}